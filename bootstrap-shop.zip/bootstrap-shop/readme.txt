/*
Bootshop 1.1
Date:3rd December 2012.
Need help? : Contact
=============================
-----------------------------
	Adhikari Surya
	Frontend Web Developer
	Email: adh.surya@gmail.com
-----------------------------
=============================
Introduction
============
Bootshop templates is highly professional, clean and Google friendly html5 and css3 code template. 
This professional online shopping cart is supported in all devices (such as desktop, iPad and iPhone) and compatible in most of the popular browser.
This template is suitable for any kinds of online shopping cart.
Different resources and technologies has been implemented at the time of development. So, this is very flexible and easy to extend for new features and pages.

The clean and modern look allows you to use the theme for every kind of online shop.
In combination with the powerful option to change the colour of all elements, you will be given the possibility to make a unique e-commerce template that stands out .  
As your test of colour you may use different bootstrap based **BOOTSWATCH  css**  or **BOOTSWATCH  Less**  (http://bootswatch.com/) . 

Anyone can easily add and remove components as it's based on the Bootstrap framework. Normally all the frontend pages are included in the file.
This shopping cart code is  included less.js ( www.lesscss.org ) for compilation of  less file,
Moreover, Font Awesome is in use as a icon (http://fortawesome.github.com). 
So it does not matter whatever be the themes color icon will change automatically like font color.
 
All the themes from Bootswatch are supported by this template which is already included in the package.

Features:
=========

1. Available with 12 different themes in 20 Differnet patterns.
3. Clean and professional design + PSD banner and logo.
4. Less file included
5. Validate with **w3c**.
6. **BOOTSHOP** is 100% responsive template  which is suitable in different devices and systems such as desktops,  tablets and mobiles screen.
7. Font Awesome is in use as a icon


Pages Included
===============

1.	Home
2.	Product page
3.	Special offer page
4.	Product details page
5.	Products compare page
6.	Product summary page
7.	Login / Forgot password
8.	Registration page
9.	Contact us
10.	Normal informations page
11.	FAQ
12.	***COMPONENTS of PAGES***


Additional Credits:
==================
1. Twitter Bootstrap (Version 2.2.1)
2. http://bootswatch.com 
3.  www.lesscss.org
4. http://www.sxc.hu
5. http://www.google.com/webfonts
6. http://fortawesome.github.com/Font-Awesome
7. http://subtlepatterns.com
8. http://leandrovieira.com for light box

**************************************************************
===================
* PLEASE Email if more informations needed.
* if You provide me email address I will let you know about new updates.
=============================
-----------------------------
	Adhikari Surya
	Frontend Web Developer
	Email: adh.surya@gmail.com
-----------------------------
=============================